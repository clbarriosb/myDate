/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mydate;

/**
 *
 * @author Usuario
 */
public class MyDatep {
    private int day;
    private int month;
    private int year;

    public MyDatep(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public String toString() {
        return this.day + "." + this.month + "." + this.year;
    }
   

    public boolean earlier(MyDatep compared) {
        // first we'll compare years
        if ( this.year < compared.year ) {
            return true;
        }

        // if the years are the same, we'll compare the months
        if ( this.year == compared.year && this.month < compared.month ) {
            return true;
        }

        // years and months the same, we'll compare the days
        if ( this.year == compared.year && this.month == compared.month &&
                this.day < compared.day ) {
            return true;
        }

        return false;
    }
    
    public void advance(){
        if ( day <30){
            day += day;
        }
        else{
            day = 1;
            month += 1;
        }
        if ( month == 12 && day == 30){
            year += 1;
        }
    
    }
    
    public void advance(int numberOfDays){
        for ( int i=1; i<day; i++ ){
             
        }
    }
    
    public static void main(String[] args) {
        
       
        
    }
    
}
      